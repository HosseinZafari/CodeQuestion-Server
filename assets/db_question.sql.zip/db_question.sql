-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 24, 2020 at 08:04 AM
-- Server version: 5.7.26
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_question`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_code`
--

DROP TABLE IF EXISTS `t_code`;
CREATE TABLE IF NOT EXISTS `t_code` (
  `codeId` smallint(6) NOT NULL AUTO_INCREMENT,
  `userId` smallint(6) DEFAULT NULL,
  `title` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `text` text COLLATE utf8_persian_ci,
  `souce` text COLLATE utf8_persian_ci,
  `date` datetime DEFAULT NULL,
  `point` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`codeId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `t_course`
--

DROP TABLE IF EXISTS `t_course`;
CREATE TABLE IF NOT EXISTS `t_course` (
  `courseId` smallint(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) COLLATE utf8_persian_ci DEFAULT NULL,
  `text` varchar(2000) COLLATE utf8_persian_ci DEFAULT NULL,
  `link` text COLLATE utf8_persian_ci,
  `image` text COLLATE utf8_persian_ci,
  `priority` tinyint(4) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `start` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`courseId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `t_news`
--

DROP TABLE IF EXISTS `t_news`;
CREATE TABLE IF NOT EXISTS `t_news` (
  `newsId` smallint(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) COLLATE utf8_persian_ci DEFAULT NULL,
  `text` text COLLATE utf8_persian_ci,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`newsId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `t_question`
--

DROP TABLE IF EXISTS `t_question`;
CREATE TABLE IF NOT EXISTS `t_question` (
  `questionId` smallint(6) NOT NULL AUTO_INCREMENT,
  `fromUserId` smallint(6) DEFAULT NULL,
  `toUserId` smallint(6) DEFAULT NULL,
  `title` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `text` text COLLATE utf8_persian_ci,
  `type` varchar(50) COLLATE utf8_persian_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `course` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`questionId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
CREATE TABLE IF NOT EXISTS `t_user` (
  `userId` mediumint(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_persian_ci DEFAULT NULL,
  `family` varchar(50) COLLATE utf8_persian_ci DEFAULT NULL,
  `image` varchar(1000) COLLATE utf8_persian_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_persian_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `role` varchar(50) COLLATE utf8_persian_ci DEFAULT 'user',
  `token` text COLLATE utf8_persian_ci,
  `point` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `t_user`
--

INSERT INTO `t_user` (`userId`, `name`, `family`, `image`, `phone`, `email`, `role`, `token`, `point`) VALUES
(1, 'یونس', 'غلامی', 'https://ware.uncox.com/asset/profile/male/10.jpg', '(+22) 87912', 'meinkej@outlook.com', 'user', NULL, 68),
(2, 'حسین', 'ظفری', 'https://ware.uncox.com/asset/profile/male/15.jpg', '(+22) 87912', 'majordick@msn.com', 'user', NULL, 40),
(3, 'حسین', 'حیدری', 'https://ware.uncox.com/asset/profile/male/35.jpg', '(+22) 87985', 'hos@gmail.com', 'user', NULL, 98);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
